const statusEl = document.getElementById('status');
const video = document.getElementById('preview');
const btnCapture = document.getElementById('btn-capture');
const btnCancel = document.getElementById('btn-cancel');

let currentStream = null;

function stopStream() {
  if (currentStream) {
    currentStream.getTracks().forEach((t) => t.stop());
    currentStream = null;
  }
}

function startPicker() {
  chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], (streamId) => {
    if (!streamId) {
      statusEl.textContent = '선택이 취소되었습니다.';
      return;
    }
    navigator.mediaDevices
      .getUserMedia({
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: streamId,
          },
        },
      })
      .then((stream) => {
        currentStream = stream;
        video.srcObject = stream;
        statusEl.textContent = '준비되면 "지금 캡쳐" 버튼을 눌러주세요.';
        btnCapture.disabled = false;
        // 공유가 사용자에 의해 중단되면 자동으로 정리
        stream.getVideoTracks()[0].addEventListener('ended', () => {
          statusEl.textContent = '화면 공유가 종료되었습니다.';
          btnCapture.disabled = true;
        });
      })
      .catch((err) => {
        statusEl.textContent = '캡쳐 시작 실패: ' + err.message;
      });
  });
}

btnCapture.addEventListener('click', () => {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/png');
  stopStream();
  chrome.runtime.sendMessage({ type: 'DESKTOP_CAPTURE_DONE', dataUrl, autoOcr: false });
});

btnCancel.addEventListener('click', () => {
  stopStream();
  window.close();
});

window.addEventListener('beforeunload', stopStream);

startPicker();
