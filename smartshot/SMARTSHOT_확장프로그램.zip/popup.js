const msgEl = document.getElementById('msg');

document.querySelectorAll('.menu button').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const action = btn.dataset.action;

    if (action === 'desktop') {
      await chrome.runtime.sendMessage({ type: 'OPEN_DESKTOP_CAPTURE' });
      window.close();
      return;
    }

    if (action === 'show-result') {
      await chrome.runtime.sendMessage({ type: 'SHOW_RESULT_WINDOW' });
      window.close();
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      msgEl.textContent = '현재 탭을 찾을 수 없습니다.';
      return;
    }

    chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_ACTION', action }, () => {
      if (chrome.runtime.lastError) {
        msgEl.textContent = '이 페이지에서는 사용할 수 없어요. 새로고침 후 다시 시도해 주세요.';
        return;
      }
      window.close();
    });
  });
});
