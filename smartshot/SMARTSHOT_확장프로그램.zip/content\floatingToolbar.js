// SMARTSHOT 플로팅 툴바 - 모든 페이지에 주입되어 전체캡쳐 / 영역선택 / OCR추출 버튼을 띄운다.
(() => {
  if (window.top !== window.self) return; // iframe 내부에는 띄우지 않음
  if (document.getElementById('smartshot-toolbar-root')) return; // 중복 주입 방지

  const ICON = { full: '🖼', area: '✂️', ocr: '🔤', screen: '🖥' };
  const BASE_OFFSET = 20; // 기존 bottom 값
  const DEFAULT_SETTINGS = {
    saveFolderMode: 'subfolder',
    saveFolder: 'SMARTSHOT',
    fileFormat: 'png',
    toolbarSize: 'medium',
    autoOpenResult: true,
    autoSaveOnCapture: false
  };

  function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['smartshot_settings'], (data) => {
        resolve(Object.assign({}, DEFAULT_SETTINGS, data.smartshot_settings || {}));
      });
    });
  }

  function setSettings(settings) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ smartshot_settings: settings }, resolve);
    });
  }

  function getSavedPosition() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['smartshot_position'], (data) => resolve(data.smartshot_position || null));
    });
  }

  function setSavedPosition(pos) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ smartshot_position: pos }, resolve);
    });
  }

  function applyToolbarSize(root, size) {
    root.classList.remove('size-large', 'size-medium', 'size-small');
    root.classList.add('size-' + (size || 'medium'));
  }

  // 좌표가 화면 밖으로 나가지 않도록 보정한다. 다른 화면에서 드래그해 저장한 위치를
  // 더 작은 창/화면에서 그대로 적용하거나, 크기 설정을 바꿔 툴바 폭이 달라질 때도
  // 항상 화면 안에 들어오게 하기 위함이다.
  const EDGE_MARGIN = 28; // 화면 가장자리에 딱 붙지 않도록 항상 남겨두는 여유 공간 (기본 right 값과 맞춤)

  function clampToolbarPosition(root, left, top) {
    const rect = root.getBoundingClientRect();
    const maxLeft = Math.max(EDGE_MARGIN, window.innerWidth - rect.width - EDGE_MARGIN);
    const maxTop = Math.max(EDGE_MARGIN, window.innerHeight - rect.height - EDGE_MARGIN);
    return {
      left: Math.min(Math.max(EDGE_MARGIN, left), maxLeft),
      top: Math.min(Math.max(EDGE_MARGIN, top), maxTop)
    };
  }

  function setToolbarPosition(root, left, top) {
    const clamped = clampToolbarPosition(root, left, top);
    root.style.left = clamped.left + 'px';
    root.style.top = clamped.top + 'px';
    root.style.right = 'auto';
    root.style.bottom = 'auto';
    return clamped;
  }

  function isPositioned(root) {
    return root.style.left && root.style.left !== 'auto';
  }

  // 가로 위치는 항상 화면 우측 가장자리(자석처럼 고정)에서 계산하고, 세로(top)만
  // 실제로 의미 있는 값이라 저장한다. 가로는 창 너비가 바뀌어도 매번 다시 계산되므로
  // 별도로 저장하거나 보정할 필요가 없다.
  function rightLockedLeft(root) {
    const rect = root.getBoundingClientRect();
    return window.innerWidth - EDGE_MARGIN - rect.width;
  }

  // 드래그 핸들을 끌면 툴바를 옮길 수 있게 한다. 자석처럼 가로 위치는 항상 화면
  // 우측 가장자리에 붙어 있고, 위아래로만 움직인다. 다음 페이지 방문 시에도
  // 같은 높이에서 우측에 붙은 채로 뜨도록 세로 위치만 저장해둔다.
  function makeDraggable(handle, root) {
    let dragging = false;
    let offsetY = 0;

    function onMove(e) {
      if (!dragging) return;
      setToolbarPosition(root, rightLockedLeft(root), e.clientY - offsetY);
    }

    function onUp() {
      if (!dragging) return;
      dragging = false;
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      const rect = root.getBoundingClientRect();
      setSavedPosition({ top: rect.top });
    }

    handle.addEventListener('mousedown', (e) => {
      e.preventDefault();
      dragging = true;
      const rect = root.getBoundingClientRect();
      offsetY = e.clientY - rect.top;
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    // 창 크기가 바뀌어도(결과 창과 나란히 보이며 자동으로 좁아지는 경우 등) 가로는
    // 항상 우측에 다시 붙고, 세로는 화면 안에 들어오도록만 재보정한다.
    window.addEventListener('resize', () => {
      if (!isPositioned(root)) return;
      const rect = root.getBoundingClientRect();
      const clamped = setToolbarPosition(root, rightLockedLeft(root), rect.top);
      setSavedPosition({ top: clamped.top });
    });
  }

  function injectToolbar() {
    const root = document.createElement('div');
    root.id = 'smartshot-toolbar-root';
    root.classList.add('size-medium', 'collapsed'); // 기본은 영역선택 버튼만 보이는 단순한 모습으로 시작
    root.style.bottom = BASE_OFFSET + 'px';
    root.innerHTML = `
      <div class="smartshot-mini-row">
        <div class="smartshot-mini smartshot-drag-handle" title="끌어서 위치 이동">✥</div>
        <button class="smartshot-mini close" data-action="close" title="이 페이지에서 닫기">✕</button>
      </div>
      <button class="smartshot-btn area" data-action="area" title="원하는 영역을 드래그해서 캡쳐합니다"><span class="icon">${ICON.area}</span><span class="label">영역선택</span></button>
      <button class="smartshot-btn screen smartshot-extra" data-action="screen" title="지금 화면에 보이는 부분만 캡쳐합니다"><span class="icon">${ICON.screen}</span><span class="label">화면캡쳐</span></button>
      <button class="smartshot-btn full smartshot-extra" data-action="full" title="스크롤하며 전체 페이지를 캡쳐합니다"><span class="icon">${ICON.full}</span><span class="label">전체캡쳐</span></button>
      <button class="smartshot-btn ocr smartshot-extra" data-action="ocr" title="영역을 선택하면 바로 글자를 추출합니다"><span class="icon">${ICON.ocr}</span><span class="label">OCR추출</span></button>
      <div class="smartshot-bottom-row">
        <button class="smartshot-mini settings smartshot-extra" data-action="settings" title="설정">⚙</button>
        <button class="smartshot-toggle" data-action="toggle" title="더 많은 버튼(설정 포함) 보기/숨기기">▾</button>
      </div>
    `;
    document.documentElement.appendChild(root);
    makeDraggable(root.querySelector('.smartshot-drag-handle'), root);

    // 저장된 위치/크기가 있으면 그대로 적용하고, 없으면 화면 우측 하단 끝(기본값)에서 시작한다.
    (async () => {
      const settings = await getSettings();
      applyToolbarSize(root, settings.toolbarSize);

      const savedPos = await getSavedPosition();
      if (savedPos && typeof savedPos.top === 'number') {
        // 가로는 항상 우측 가장자리에 고정, 세로만 저장해둔 값을 쓴다.
        setToolbarPosition(root, rightLockedLeft(root), savedPos.top);
        return;
      }
      // 드래그한 적이 없으면 화면 우측 하단 끝에서 시작한다 (CSS의 기본 right/bottom 그대로).
    })();

    root.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const action = btn.dataset.action;
      if (action === 'toggle') {
        root.classList.toggle('collapsed');
        const toggleBtn = root.querySelector('.smartshot-toggle');
        // 접혀 있으면(영역선택만 보임) 더 펼칠 수 있다는 뜻으로 ▾, 펼쳐져 있으면 ▴
        toggleBtn.textContent = root.classList.contains('collapsed') ? '▾' : '▴';
        return;
      }
      if (action === 'settings') { openSettingsPanel(); return; }
      if (action === 'close') {
        closeSettingsPanel();
        root.remove();
        return;
      }
      if (action === 'full') fullPageCapture();
      if (action === 'area') startAreaSelect('select');
      if (action === 'screen') visibleCapture();
      if (action === 'ocr') startAreaSelect('ocr');
    });

    return root;
  }

  // ---------- 설정 패널 ----------
  function closeSettingsPanel() {
    const panel = document.getElementById('smartshot-settings-panel');
    if (panel) panel.remove();
  }

  async function openSettingsPanel() {
    closeSettingsPanel();
    const settings = await getSettings();

    const panel = document.createElement('div');
    panel.id = 'smartshot-settings-panel';
    panel.innerHTML = `
      <div class="smartshot-settings-header">
        <strong>⚙ SMARTSHOT 설정</strong>
        <button class="smartshot-settings-close" data-action="panel-close">✕</button>
      </div>
      <label class="smartshot-settings-row">
        <span>저장 위치</span>
        <select id="smartshot-setting-foldermode">
          <option value="root">다운로드 폴더에 바로 저장</option>
          <option value="subfolder">다운로드 폴더 안 SMARTSHOT 폴더에 저장</option>
        </select>
      </label>
      <label class="smartshot-settings-row">
        <span>파일 형식</span>
        <select id="smartshot-setting-format">
          <option value="png">PNG</option>
          <option value="jpg">JPG</option>
        </select>
      </label>
      <label class="smartshot-settings-row">
        <span>버튼 크기</span>
        <select id="smartshot-setting-size">
          <option value="large">대</option>
          <option value="medium">중</option>
          <option value="small">소 (아이콘만)</option>
        </select>
      </label>
      <label class="smartshot-settings-row smartshot-settings-checkbox-row">
        <input type="checkbox" id="smartshot-setting-autoopen" />
        <span>캡쳐 후 결과 창 자동으로 열기</span>
      </label>
      <p class="smartshot-settings-hint">끄면 영역선택은 클립보드 복사만, 화면/전체 캡쳐는 기록만 저장합니다. 나중에 확장 아이콘 팝업에서 "결과 창 보기"로 열 수 있어요.</p>
      <label class="smartshot-settings-row smartshot-settings-checkbox-row">
        <input type="checkbox" id="smartshot-setting-autosave" />
        <span>캡쳐 시 자동 저장</span>
      </label>
      <p class="smartshot-settings-hint">클립보드 복사와 별개로, 캡쳐할 때마다 위에서 정한 저장 위치/형식으로 파일도 같이 저장합니다.</p>
      <button class="smartshot-settings-save" data-action="panel-save">저장</button>
      <hr />
      <button class="smartshot-settings-home" data-action="panel-home">
        <span class="home-line1">🏠 스마트미디어아트센터 홈페이지</span>
        <span class="home-line2">➡ 바로 이동</span>
      </button>
    `;
    document.documentElement.appendChild(panel);
    panel.querySelector('#smartshot-setting-foldermode').value = settings.saveFolderMode;
    panel.querySelector('#smartshot-setting-format').value = settings.fileFormat;
    panel.querySelector('#smartshot-setting-size').value = settings.toolbarSize;
    panel.querySelector('#smartshot-setting-autoopen').checked = settings.autoOpenResult !== false;
    panel.querySelector('#smartshot-setting-autosave').checked = !!settings.autoSaveOnCapture;

    // 툴바 바로 위, 같은 가로 위치에 패널을 띄운다 (툴바를 끌어서 옮겼을 수도 있으므로).
    // 실제 렌더링된 패널 크기를 측정해서 화면 밖으로 나가지 않게 한다.
    const toolbarRect = toolbarRoot.getBoundingClientRect();
    const panelRect = panel.getBoundingClientRect();
    const panelWidth = panelRect.width || 200;
    const panelHeight = panelRect.height || 300;
    const gap = 12;

    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.left = Math.max(8, Math.min(window.innerWidth - panelWidth - 8, toolbarRect.left)) + 'px';

    // 기본은 툴바 바로 위에 띄우되, 툴바가 화면 위쪽에 있어서 위 공간이 부족하면
    // (패널 전체가 화면 밖으로 밀려나 닫기 버튼도 못 누르게 되는 것을 막기 위해)
    // 화면 안에 들어오도록 위치를 보정한다.
    let top = toolbarRect.top - panelHeight - gap;
    top = Math.max(8, Math.min(top, window.innerHeight - panelHeight - 8));
    panel.style.top = top + 'px';

    panel.addEventListener('click', async (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const action = btn.dataset.action;
      if (action === 'panel-close') {
        closeSettingsPanel();
        return;
      }
      if (action === 'panel-save') {
        const saveFolderMode = panel.querySelector('#smartshot-setting-foldermode').value;
        const format = panel.querySelector('#smartshot-setting-format').value;
        const toolbarSize = panel.querySelector('#smartshot-setting-size').value;
        const autoOpenResult = panel.querySelector('#smartshot-setting-autoopen').checked;
        const autoSaveOnCapture = panel.querySelector('#smartshot-setting-autosave').checked;
        await setSettings({
          saveFolderMode,
          saveFolder: DEFAULT_SETTINGS.saveFolder,
          fileFormat: format,
          toolbarSize,
          autoOpenResult,
          autoSaveOnCapture
        });
        applyToolbarSize(toolbarRoot, toolbarSize);
        if (isPositioned(toolbarRoot)) {
          // 크기가 바뀌면서 화면 밖으로 나갈 수 있으니 위치를 다시 보정한다.
          const rect = toolbarRoot.getBoundingClientRect();
          const clamped = setToolbarPosition(toolbarRoot, rightLockedLeft(toolbarRoot), rect.top);
          setSavedPosition({ top: clamped.top });
        }
        showToast('설정이 저장되었습니다.');
        await delay(1200);
        hideToast();
        closeSettingsPanel();
        return;
      }
      if (action === 'panel-home') {
        chrome.runtime.sendMessage({ type: 'OPEN_HOMEPAGE' });
        closeSettingsPanel();
        return;
      }
    });
  }

  const toolbarRoot = injectToolbar();

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== 'TRIGGER_ACTION') return;
    if (msg.action === 'full') fullPageCapture();
    if (msg.action === 'area') startAreaSelect('select');
    if (msg.action === 'screen') visibleCapture();
    if (msg.action === 'ocr') startAreaSelect('ocr');
  });

  function showToast(text) {
    let toast = document.getElementById('smartshot-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'smartshot-toast';
      document.documentElement.appendChild(toast);
    }
    toast.textContent = text;
    return toast;
  }

  function hideToast() {
    const toast = document.getElementById('smartshot-toast');
    if (toast) toast.remove();
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function sendMessage(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (response) => resolve(response));
    });
  }

  async function withHiddenToolbar(fn) {
    toolbarRoot.style.display = 'none';
    await delay(60);
    try {
      return await fn();
    } finally {
      toolbarRoot.style.display = '';
    }
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
  }

  function canvasToBlob(canvas) {
    return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
  }

  async function copyCanvasToClipboard(canvas) {
    const blob = await canvasToBlob(canvas);
    if (!blob) return;
    await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
  }

  function toJpegDataUrl(srcDataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const c = canvas.getContext('2d');
        c.fillStyle = '#fff'; // JPG는 투명 배경을 지원하지 않으므로 흰 배경으로 채운다
        c.fillRect(0, 0, canvas.width, canvas.height);
        c.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/jpeg', 0.92));
      };
      img.onerror = reject;
      img.src = srcDataUrl;
    });
  }

  // 설정에서 "캡쳐 시 다운로드 폴더에도 자동 저장"을 켜둔 경우, 결과 창의 저장
  // 버튼을 누르지 않아도 캡쳐할 때마다 바로 파일로 저장한다.
  async function maybeAutoSaveCapture(dataUrl) {
    const settings = await getSettings();
    if (!settings.autoSaveOnCapture) return false;

    const ext = settings.fileFormat === 'jpg' ? 'jpg' : 'png';
    const finalDataUrl = ext === 'jpg' ? await toJpegDataUrl(dataUrl) : dataUrl;

    const ts = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const baseName = `SMARTSHOT_${ts.getFullYear()}${pad(ts.getMonth() + 1)}${pad(ts.getDate())}_${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}.${ext}`;
    const folder = settings.saveFolderMode === 'subfolder' && settings.saveFolder ? settings.saveFolder + '/' : '';

    await sendMessage({ type: 'SAVE_PNG', dataUrl: finalDataUrl, filename: folder + baseName });
    return true;
  }

  async function captureVisible() {
    const res = await sendMessage({ type: 'CAPTURE_VISIBLE' });
    if (!res || res.error) throw new Error((res && res.error) || '캡쳐 실패');
    return res.dataUrl;
  }

  // 토스트를 막 지워도 브라우저가 그 변화를 화면에 실제로 그리기 전에 캡쳐가 먼저
  // 일어날 수 있어서, 다음 페인트가 끝날 때까지 한 번 더 기다려준다.
  function nextPaint() {
    return new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  }

  // ---------- 보이는 화면만 캡쳐 ----------
  async function visibleCapture() {
    try {
      const dataUrl = await withHiddenToolbar(async () => {
        const captured = await captureVisible();
        await sendMessage({ type: 'FULLPAGE_DONE', dataUrl: captured });
        return captured;
      });
      const saved = await maybeAutoSaveCapture(dataUrl);
      // 설정에서 결과 창 자동 열기를 꺼둔 경우에도 캡쳐가 됐다는 걸 알 수 있게 한다.
      showToast(saved ? '캡쳐 완료 (기록 저장 + 파일 저장)' : '캡쳐 완료 (기록에 저장됨)');
      await delay(1000);
      hideToast();
    } catch (err) {
      showToast('캡쳐 실패: ' + err.message);
      await delay(2000);
      hideToast();
    }
  }

  // ---------- 전체 페이지 캡쳐 ----------
  async function fullPageCapture() {
    try {
      await withHiddenToolbar(async () => {
        showToast('전체 페이지 캡쳐 준비 중...');
        const originalX = window.scrollX;
        const originalY = window.scrollY;
        const dpr = window.devicePixelRatio || 1;
        const viewportH = window.innerHeight;
        const viewportW = window.innerWidth;
        const totalH = Math.max(
          document.documentElement.scrollHeight,
          document.body ? document.body.scrollHeight : 0,
          viewportH
        );

        const frames = [];
        let lastY = -1;
        let targetY = 0;
        let guard = 0;

        while (guard < 200) {
          guard++;
          window.scrollTo(0, targetY);
          showToast(`전체 페이지 캡쳐 중... (${frames.length + 1})`);
          await delay(280);
          const actualY = window.scrollY;
          if (frames.length > 0 && actualY === lastY) break; // 더 이상 스크롤되지 않음 (끝)

          // 캡쳐 직전에 토스트를 숨겨서 결과 이미지에 안내 문구가 찍히지 않게 한다.
          hideToast();
          await nextPaint();
          const dataUrl = await captureVisible();

          frames.push({ y: actualY, dataUrl });
          lastY = actualY;
          if (actualY + viewportH >= totalH) break;
          targetY = actualY + viewportH;
        }

        window.scrollTo(originalX, originalY);
        showToast('이미지 합성 중...');

        const canvas = document.createElement('canvas');
        canvas.width = Math.round(viewportW * dpr);
        canvas.height = Math.round(totalH * dpr);
        const ctx = canvas.getContext('2d');

        for (const frame of frames) {
          const img = await loadImage(frame.dataUrl);
          ctx.drawImage(img, 0, Math.round(frame.y * dpr));
        }

        const finalDataUrl = canvas.toDataURL('image/png');
        await sendMessage({ type: 'FULLPAGE_DONE', dataUrl: finalDataUrl });
        const saved = await maybeAutoSaveCapture(finalDataUrl);
        showToast(saved ? '캡쳐 완료 (기록 저장 + 파일 저장)' : '캡쳐 완료 (기록에 저장됨)');
        await delay(1000);
      });
    } catch (err) {
      showToast('캡쳐 실패: ' + err.message);
      await delay(2000);
    } finally {
      hideToast();
    }
  }

  // ---------- 영역 선택 캡쳐 / OCR추출 ----------
  async function startAreaSelect(mode) {
    let baseDataUrl;
    try {
      baseDataUrl = await withHiddenToolbar(() => captureVisible());
    } catch (err) {
      showToast('캡쳐 실패: ' + err.message);
      await delay(2000);
      hideToast();
      return;
    }

    toolbarRoot.style.display = 'none';

    const overlay = document.createElement('div');
    overlay.id = 'smartshot-overlay';
    overlay.innerHTML = `<div class="smartshot-hint">${mode === 'ocr' ? '영역을 드래그하면 바로 글자를 추출합니다' : '영역을 드래그해서 선택하세요'} (Esc: 취소)</div>`;
    document.documentElement.appendChild(overlay);

    let startX = 0, startY = 0, selecting = false, box = null, dimLabel = null;
    const dpr = window.devicePixelRatio || 1;

    function cleanup() {
      overlay.remove();
      document.removeEventListener('keydown', onKeyDown, true);
      toolbarRoot.style.display = '';
    }

    function onKeyDown(e) {
      if (e.key === 'Escape') {
        cleanup();
      }
    }
    document.addEventListener('keydown', onKeyDown, true);

    overlay.addEventListener('mousedown', (e) => {
      selecting = true;
      startX = e.clientX;
      startY = e.clientY;
      box = document.createElement('div');
      box.className = 'smartshot-select-box';
      box.style.left = startX + 'px';
      box.style.top = startY + 'px';
      box.style.width = '0px';
      box.style.height = '0px';
      overlay.appendChild(box);

      dimLabel = document.createElement('div');
      dimLabel.className = 'smartshot-select-dim';
      overlay.appendChild(dimLabel);

      // box-shadow 스포트라이트 효과를 쓰는 동안은 오버레이 자체의 어두운 배경을 끈다.
      overlay.classList.add('has-box');
    });

    overlay.addEventListener('mousemove', (e) => {
      if (!selecting || !box) return;
      const x = Math.min(e.clientX, startX);
      const y = Math.min(e.clientY, startY);
      const w = Math.abs(e.clientX - startX);
      const h = Math.abs(e.clientY - startY);
      box.style.left = x + 'px';
      box.style.top = y + 'px';
      box.style.width = w + 'px';
      box.style.height = h + 'px';

      if (dimLabel) {
        dimLabel.textContent = `${Math.round(w * dpr)} × ${Math.round(h * dpr)}`;
        const labelTop = y > 24 ? y - 22 : y + h + 6;
        dimLabel.style.left = x + 'px';
        dimLabel.style.top = labelTop + 'px';
      }
    });

    overlay.addEventListener('mouseup', async (e) => {
      if (!selecting) return;
      selecting = false;
      const x = Math.min(e.clientX, startX);
      const y = Math.min(e.clientY, startY);
      const w = Math.abs(e.clientX - startX);
      const h = Math.abs(e.clientY - startY);
      cleanup();

      if (w < 6 || h < 6) return; // 너무 작으면 취소로 간주

      try {
        const img = await loadImage(baseDataUrl);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(
          img,
          Math.round(x * dpr), Math.round(y * dpr), Math.round(w * dpr), Math.round(h * dpr),
          0, 0, Math.round(w * dpr), Math.round(h * dpr)
        );
        const croppedDataUrl = canvas.toDataURL('image/png');
        await sendMessage({ type: 'AREA_SELECT_DONE', dataUrl: croppedDataUrl, mode });

        const doneParts = [];
        try {
          await copyCanvasToClipboard(canvas);
          doneParts.push('클립보드 복사');
        } catch (clipErr) {
          // 클립보드 복사가 막혀 있어도 결과 창에서 다시 복사할 수 있으니 조용히 무시한다.
        }
        try {
          if (await maybeAutoSaveCapture(croppedDataUrl)) doneParts.push('파일 저장');
        } catch (saveErr) {
          // 자동 저장이 실패해도 결과 창에서 다시 저장할 수 있으니 조용히 무시한다.
        }
        if (doneParts.length) {
          showToast(doneParts.join(' + ') + ' 완료');
          await delay(1200);
          hideToast();
        }
      } catch (err) {
        showToast('자르기 실패: ' + err.message);
        await delay(2000);
        hideToast();
      }
    });
  }
})();
