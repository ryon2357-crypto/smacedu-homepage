// SMARTSHOT background service worker
// 모든 캡쳐 요청을 받아 chrome.tabs API를 호출하고, 결과 이미지를 storage에 저장 후
// 결과 화면을 화면 우측에 고정된 작은 창으로 연다.

const RESULT_PANEL_WIDTH = 460;
const MAX_HISTORY = 30;
// Windows는 창 가장자리에 눈에 보이지 않는 리사이즈 테두리가 있어서, 두 창을
// 계산대로 딱 붙여놔도 그 사이에 틈이 보인다. 그만큼 겹치게 보정한다.
const WINDOW_BORDER_FUDGE = 8;

async function getResultWindowId() {
  const data = await chrome.storage.session.get(['smartshot_result_window_id']);
  return data.smartshot_result_window_id || null;
}

async function setResultWindowId(id) {
  await chrome.storage.session.set({ smartshot_result_window_id: id || null });
}

async function getSourceWindowId() {
  const data = await chrome.storage.session.get(['smartshot_source_window_id']);
  return data.smartshot_source_window_id || null;
}

async function setSourceWindowId(id) {
  await chrome.storage.session.set({ smartshot_source_window_id: id || null });
}

async function getRightEdgeBounds() {
  let left = 80, top = 60, height = 900;
  try {
    const displays = await chrome.system.display.getInfo();
    const primary = displays.find((d) => d.isPrimary) || displays[0];
    if (primary) {
      const wa = primary.workArea;
      left = Math.round(wa.left + wa.width - RESULT_PANEL_WIDTH - WINDOW_BORDER_FUDGE);
      top = wa.top;
      height = wa.height;
    }
  } catch (e) {
    // chrome.system.display를 못 쓰면 기본값으로 연다.
  }
  // 화면 우측 끝과도 틈 없이 붙도록, 오른쪽으로도 테두리만큼 더 넓힌다.
  return { left, top, width: RESULT_PANEL_WIDTH + WINDOW_BORDER_FUDGE, height };
}

async function openResultWindow() {
  const bounds = await getRightEdgeBounds();
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL('result.html'),
    type: 'popup',
    left: bounds.left,
    top: bounds.top,
    width: bounds.width,
    height: bounds.height
  });
  await setResultWindowId(win.id);
}

// 캡쳐를 시작한 원래 브라우저 창을 화면 왼쪽에 맞춰 결과 창과 나란히 보이게 한다.
async function positionSourceWindowLeft(sourceWindowId) {
  if (!sourceWindowId) return;
  try {
    const displays = await chrome.system.display.getInfo();
    const primary = displays.find((d) => d.isPrimary) || displays[0];
    if (!primary) return;
    const wa = primary.workArea;
    // 결과 창과 맞닿는 우측만 틈 없이 붙도록 테두리만큼 넓힌다.
    // 좌측은 듀얼 모니터 환경에서 옆 모니터를 침범할 수 있어 보정하지 않는다.
    const leftWidth = Math.max(300, wa.width - RESULT_PANEL_WIDTH + WINDOW_BORDER_FUDGE);

    // 창이 최대화 상태면 먼저 풀어줘야 위치/크기 조정이 반영된다.
    await chrome.windows.update(sourceWindowId, { state: 'normal' });
    await chrome.windows.update(sourceWindowId, {
      left: wa.left,
      top: wa.top,
      width: leftWidth,
      height: wa.height
    });
  } catch (e) {
    // 창이 이미 닫혔거나 조정할 수 없는 경우 조용히 무시한다.
  }
}

async function appendToHistory(dataUrl, ts) {
  const data = await chrome.storage.local.get(['smartshot_history']);
  const history = data.smartshot_history || [];
  history.push({ dataUrl, ts });
  while (history.length > MAX_HISTORY) history.shift();
  await chrome.storage.local.set({ smartshot_history: history });
}

async function getAutoOpenResultSetting() {
  const data = await chrome.storage.local.get(['smartshot_settings']);
  return !data.smartshot_settings || data.smartshot_settings.autoOpenResult !== false;
}

async function storeAndOpenResult(dataUrl, autoOcr, sourceWindowId) {
  const ts = Date.now();
  await chrome.storage.local.set({
    smartshot_image: dataUrl,
    smartshot_autoOcr: !!autoOcr,
    smartshot_ts: ts
  });
  await appendToHistory(dataUrl, ts);

  // 설정에서 자동으로 열지 않도록 꺼두었으면, 이미 열려 있는 결과 창이 있어도
  // 건드리지 않고 조용히 저장만 한다. 나중에 팝업의 "결과 창 보기"로 직접 확인한다.
  const autoOpen = await getAutoOpenResultSetting();
  if (!autoOpen) return;

  // 이미 떠 있는 결과 창이 있으면 새 창을 또 띄우지 않고 그 창에 새 캡쳐를 반영한다.
  const existingId = await getResultWindowId();
  if (existingId) {
    try {
      const win = await chrome.windows.get(existingId, { populate: true });
      const tab = win.tabs && win.tabs[0];
      if (tab && tab.id) {
        if (sourceWindowId) {
          await setSourceWindowId(sourceWindowId);
          positionSourceWindowLeft(sourceWindowId);
        }
        await chrome.windows.update(existingId, { focused: true, drawAttention: true });
        chrome.tabs.sendMessage(tab.id, { type: 'NEW_CAPTURE' });
        return;
      }
    } catch (e) {
      // 창이 이미 닫혀 있으면 아래에서 새로 연다.
    }
  }

  if (sourceWindowId) {
    await setSourceWindowId(sourceWindowId);
    positionSourceWindowLeft(sourceWindowId);
  }
  await openResultWindow();
}

// 자동으로 열리지 않은 캡쳐를 나중에 직접 확인하고 싶을 때 (팝업의 "결과 창 보기" 버튼) 쓴다.
// 설정과 무관하게 항상 켜져 있는 최신 내용으로 띄운다.
async function showResultWindow(sourceWindowId) {
  const existingId = await getResultWindowId();
  if (existingId) {
    try {
      const win = await chrome.windows.get(existingId, { populate: true });
      const tab = win.tabs && win.tabs[0];
      await chrome.windows.update(existingId, { focused: true, drawAttention: true });
      if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: 'NEW_CAPTURE' });
      return;
    } catch (e) {
      // 창이 이미 닫혀 있으면 아래에서 새로 연다.
    }
  }
  if (sourceWindowId) {
    await setSourceWindowId(sourceWindowId);
    positionSourceWindowLeft(sourceWindowId);
  }
  await openResultWindow();
}

chrome.windows.onRemoved.addListener(async (closedId) => {
  const resultId = await getResultWindowId();
  if (resultId === closedId) {
    await setResultWindowId(null);
    // 결과 창을 닫으면 쌓여 있던 캡쳐 기록도 함께 비워서, 다음에 열 때는 깨끗하게 시작한다.
    await chrome.storage.local.remove(['smartshot_history', 'smartshot_image', 'smartshot_autoOcr', 'smartshot_ts']);
  }
  const sourceId = await getSourceWindowId();
  if (sourceId === closedId) await setSourceWindowId(null);
});

// 결과 창을 드래그로 늘리거나 줄이면, 캡쳐를 시작한 크롬 창의 너비를 그만큼
// 자동으로 줄이거나 늘려서 두 창이 겹치지 않게 한다 (결과 창 → 크롬 창 단방향).
chrome.windows.onBoundsChanged.addListener(async (changedWindow) => {
  const resultId = await getResultWindowId();
  if (!resultId || changedWindow.id !== resultId) return;

  const sourceId = await getSourceWindowId();
  if (!sourceId) return;

  try {
    const sourceWin = await chrome.windows.get(sourceId);
    if (sourceWin.state !== 'normal') return; // 최대화/최소화 상태면 건드리지 않는다.
    const newWidth = Math.round(changedWindow.left - sourceWin.left + WINDOW_BORDER_FUDGE);
    if (newWidth >= 300) {
      await chrome.windows.update(sourceId, { width: newWidth });
    }
  } catch (e) {
    // 크롬 창이 이미 닫혀 있으면 무시한다.
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  switch (msg.type) {
    case 'CAPTURE_VISIBLE': {
      const windowId = sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
      chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ dataUrl });
        }
      });
      return true; // async response
    }

    case 'FULLPAGE_DONE': {
      storeAndOpenResult(msg.dataUrl, false, sender.tab ? sender.tab.windowId : undefined);
      sendResponse({ ok: true });
      return false;
    }

    case 'AREA_SELECT_DONE': {
      storeAndOpenResult(msg.dataUrl, msg.mode === 'ocr', sender.tab ? sender.tab.windowId : undefined);
      sendResponse({ ok: true });
      return false;
    }

    case 'DESKTOP_CAPTURE_DONE': {
      storeAndOpenResult(msg.dataUrl, !!msg.autoOcr);
      if (sender.tab && sender.tab.id) {
        chrome.tabs.remove(sender.tab.id);
      }
      sendResponse({ ok: true });
      return false;
    }

    case 'OPEN_DESKTOP_CAPTURE': {
      chrome.tabs.create({ url: chrome.runtime.getURL('capture-desktop.html') });
      sendResponse({ ok: true });
      return false;
    }

    case 'SAVE_PNG': {
      const filename = msg.filename || ('SMARTSHOT_' + Date.now() + '.png');
      chrome.downloads.download({
        url: msg.dataUrl,
        filename,
        saveAs: false // 설정에서 지정한 폴더/형식대로 대화상자 없이 바로 저장
      }, (downloadId) => {
        if (!chrome.runtime.lastError && downloadId !== undefined) {
          sendResponse({ ok: true, fallback: false });
          return;
        }
        // 하위 폴더 생성이 막혀 있는 환경일 수 있으니, 하위 폴더 없이
        // 다운로드 폴더에 바로 저장하는 것으로 재시도한다.
        const baseName = filename.split('/').pop();
        chrome.downloads.download({
          url: msg.dataUrl,
          filename: baseName,
          saveAs: false
        }, (fallbackId) => {
          sendResponse({ ok: !chrome.runtime.lastError && fallbackId !== undefined, fallback: true });
        });
      });
      return true;
    }

    case 'OPEN_HOMEPAGE': {
      chrome.tabs.create({ url: 'https://www.smacedu.kr' });
      sendResponse({ ok: true });
      return false;
    }

    case 'OPEN_SHORTCUTS': {
      chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
      sendResponse({ ok: true });
      return false;
    }

    case 'SHOW_RESULT_WINDOW': {
      (async () => {
        const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        await showResultWindow(activeTab ? activeTab.windowId : undefined);
        sendResponse({ ok: true });
      })();
      return true;
    }

    default:
      return false;
  }
});

// 단축키(기본 Alt+S)로 영역선택을 바로 실행한다. 활성 탭에 플로팅 툴바가 이미
// 주입되어 있으므로, 그 쪽에 버튼을 누른 것과 동일한 메시지를 보내기만 하면 된다.
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'trigger-area-select') return;
  const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (activeTab && activeTab.id) {
    chrome.tabs.sendMessage(activeTab.id, { type: 'TRIGGER_ACTION', action: 'area' });
  }
});
