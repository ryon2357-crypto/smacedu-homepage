let worker = null;
let lastOcrText = '';
let currentSettings = { saveFolderMode: 'subfolder', saveFolder: 'SMARTSHOT', fileFormat: 'png' };

const statusEl = document.getElementById('status');
const canvasEl = document.getElementById('captured-canvas');
const overlayEl = document.getElementById('overlay-canvas');
const canvasWrap = document.getElementById('canvas-wrap');
const ctx = canvasEl.getContext('2d');
const octx = overlayEl.getContext('2d');
const textArea = document.getElementById('ocr-text');
const ocrSection = document.getElementById('ocr-result-section');
const saveBtn = document.getElementById('btn-save-png');

async function loadSettings() {
  const data = await chrome.storage.local.get(['smartshot_settings']);
  currentSettings = Object.assign(
    { saveFolderMode: 'subfolder', saveFolder: 'SMARTSHOT', fileFormat: 'png' },
    data.smartshot_settings || {}
  );
  if (saveBtn) saveBtn.textContent = `💾 ${currentSettings.fileFormat.toUpperCase()}로 저장`;
}

function toFormatDataUrl(srcDataUrl, format) {
  if (format !== 'jpg') return Promise.resolve(srcDataUrl);
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const c = canvas.getContext('2d');
      c.fillStyle = '#fff'; // JPG는 투명 배경을 지원하지 않으므로 흰 배경으로 채운다
      c.fillRect(0, 0, canvas.width, canvas.height);
      c.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/jpeg', 0.92));
    };
    img.onerror = reject;
    img.src = srcDataUrl;
  });
}

function setStatus(text) {
  statusEl.textContent = text;
}

function flashStatus(text) {
  const prev = statusEl.textContent;
  setStatus(text);
  setTimeout(() => setStatus(prev), 1500);
}

function loadCapturedImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      canvasEl.width = img.naturalWidth;
      canvasEl.height = img.naturalHeight;
      overlayEl.width = img.naturalWidth;
      overlayEl.height = img.naturalHeight;
      ctx.drawImage(img, 0, 0);
      resolve();
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

// ---------- 주석(사각형 / 원형 / 화살표 / 선 / 텍스트 / 모자이크) ----------
let currentTool = null;
let currentShapeColor = document.getElementById('annotate-shape-color').value;
let currentThickness = parseInt(document.getElementById('annotate-thickness').value, 10);
let currentTextColor = document.getElementById('annotate-text-color').value;
let currentTextBgColor = document.getElementById('annotate-text-bg-color').value;
let textBgTransparent = document.getElementById('annotate-text-bg-transparent').checked;
let currentFontSize = parseInt(document.getElementById('annotate-fontsize').value, 10);
let textBold = document.getElementById('annotate-bold-toggle').classList.contains('active');
let dragStart = null;
const undoStack = [];

// 텍스트 입력창의 줄 너비를 재기 위한 측정용 캔버스 (실제 화면에는 그리지 않는다)
const measureCanvas = document.createElement('canvas');
const measureCtx = measureCanvas.getContext('2d');

function textFontString(sizePx, bold) {
  return `${bold ? 'bold ' : ''}${sizePx}px "Segoe UI", "Malgun Gothic", sans-serif`;
}

// 방금 찍은 텍스트 1개만 다시 편집할 수 있게 기억해둔다. 그 사이 다른 작업(도형,
// 되돌리기, 새 캡쳐)이 끼면 더 이상 안전하게 되돌릴 수 없으므로 무효화한다.
// (도형/선은 "방금 그린 것 이동"을 시도해봤으나 실제로 잘 동작하지 않아 제외했다.)
let lastAction = null;
const editLastBtn = document.getElementById('btn-edit-last-text');

function updateEditLastButton() {
  editLastBtn.disabled = !lastAction;
  editLastBtn.textContent = '✏️ 마지막 텍스트 편집';
}

function getDisplayScale() {
  const rect = canvasEl.getBoundingClientRect();
  return rect.width ? rect.width / canvasEl.width : 1;
}

function pushUndoSnapshot() {
  lastAction = null;
  updateEditLastButton();
  const snapshot = canvasEl.toDataURL('image/png');
  undoStack.push(snapshot);
  if (undoStack.length > 20) undoStack.shift();
  return snapshot;
}

function undoLast() {
  const last = undoStack.pop();
  if (!last) {
    flashStatus('되돌릴 작업이 없습니다.');
    return;
  }
  lastAction = null;
  updateEditLastButton();
  const img = new Image();
  img.onload = () => {
    ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
    ctx.drawImage(img, 0, 0);
  };
  img.src = last;
}

function getCanvasPos(e) {
  const rect = canvasEl.getBoundingClientRect();
  const scaleX = canvasEl.width / rect.width;
  const scaleY = canvasEl.height / rect.height;
  return {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top) * scaleY
  };
}

function strokeWidthFor() {
  return currentThickness;
}

function drawBox(targetCtx, start, end, color) {
  const x = Math.min(start.x, end.x);
  const y = Math.min(start.y, end.y);
  const w = Math.abs(end.x - start.x);
  const h = Math.abs(end.y - start.y);
  targetCtx.save();
  targetCtx.strokeStyle = color;
  targetCtx.lineWidth = strokeWidthFor();
  targetCtx.strokeRect(x, y, w, h);
  targetCtx.restore();
}

function drawCircle(targetCtx, start, end, color) {
  const x = Math.min(start.x, end.x);
  const y = Math.min(start.y, end.y);
  const w = Math.abs(end.x - start.x);
  const h = Math.abs(end.y - start.y);
  targetCtx.save();
  targetCtx.strokeStyle = color;
  targetCtx.lineWidth = strokeWidthFor();
  targetCtx.beginPath();
  targetCtx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
  targetCtx.stroke();
  targetCtx.restore();
}

function drawArrow(targetCtx, start, end, color) {
  const headLen = Math.max(14, Math.round(canvasEl.width / 80));
  const angle = Math.atan2(end.y - start.y, end.x - start.x);
  targetCtx.save();
  targetCtx.strokeStyle = color;
  targetCtx.fillStyle = color;
  targetCtx.lineWidth = strokeWidthFor();
  targetCtx.lineCap = 'round';
  targetCtx.beginPath();
  targetCtx.moveTo(start.x, start.y);
  targetCtx.lineTo(end.x, end.y);
  targetCtx.stroke();
  targetCtx.beginPath();
  targetCtx.moveTo(end.x, end.y);
  targetCtx.lineTo(end.x - headLen * Math.cos(angle - Math.PI / 6), end.y - headLen * Math.sin(angle - Math.PI / 6));
  targetCtx.lineTo(end.x - headLen * Math.cos(angle + Math.PI / 6), end.y - headLen * Math.sin(angle + Math.PI / 6));
  targetCtx.closePath();
  targetCtx.fill();
  targetCtx.restore();
}

function drawLine(targetCtx, start, end, color) {
  targetCtx.save();
  targetCtx.strokeStyle = color;
  targetCtx.lineWidth = strokeWidthFor();
  targetCtx.lineCap = 'round';
  targetCtx.beginPath();
  targetCtx.moveTo(start.x, start.y);
  targetCtx.lineTo(end.x, end.y);
  targetCtx.stroke();
  targetCtx.restore();
}

function drawMosaicPreview(targetCtx, start, end) {
  const x = Math.min(start.x, end.x);
  const y = Math.min(start.y, end.y);
  const w = Math.abs(end.x - start.x);
  const h = Math.abs(end.y - start.y);
  targetCtx.save();
  targetCtx.setLineDash([6, 4]);
  targetCtx.strokeStyle = 'rgba(100,100,100,0.9)';
  targetCtx.lineWidth = 2;
  targetCtx.strokeRect(x, y, w, h);
  targetCtx.fillStyle = 'rgba(120,120,120,0.3)';
  targetCtx.fillRect(x, y, w, h);
  targetCtx.restore();
}

function applyMosaic(start, end) {
  const x = Math.round(Math.min(start.x, end.x));
  const y = Math.round(Math.min(start.y, end.y));
  const w = Math.round(Math.abs(end.x - start.x));
  const h = Math.round(Math.abs(end.y - start.y));
  if (w < 2 || h < 2) return;

  const blockSize = Math.max(6, Math.round(Math.min(w, h) / 12));
  const smallW = Math.max(1, Math.round(w / blockSize));
  const smallH = Math.max(1, Math.round(h / blockSize));

  const regionCanvas = document.createElement('canvas');
  regionCanvas.width = w;
  regionCanvas.height = h;
  regionCanvas.getContext('2d').putImageData(ctx.getImageData(x, y, w, h), 0, 0);

  const smallCanvas = document.createElement('canvas');
  smallCanvas.width = smallW;
  smallCanvas.height = smallH;
  smallCanvas.getContext('2d').drawImage(regionCanvas, 0, 0, w, h, 0, 0, smallW, smallH);

  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(x, y, w, h);
  ctx.drawImage(smallCanvas, 0, 0, smallW, smallH, x, y, w, h);
  ctx.restore();
}

function drawPreview(tool, start, end) {
  octx.clearRect(0, 0, overlayEl.width, overlayEl.height);
  if (tool === 'box') drawBox(octx, start, end, currentShapeColor);
  if (tool === 'circle') drawCircle(octx, start, end, currentShapeColor);
  if (tool === 'arrow') drawArrow(octx, start, end, currentShapeColor);
  if (tool === 'line') drawLine(octx, start, end, currentShapeColor);
  if (tool === 'mosaic') drawMosaicPreview(octx, start, end);
}

function cssToCanvasPos(cssX, cssY) {
  const rect = canvasEl.getBoundingClientRect();
  const scaleX = canvasEl.width / rect.width;
  const scaleY = canvasEl.height / rect.height;
  return { x: cssX * scaleX, y: cssY * scaleY };
}

function openTextInput({ cssX: startX, cssY: startY, initialText = '' }) {
  const existing = document.getElementById('smartshot-text-box');
  if (existing && existing._commit) existing._commit(); // 입력 중이던 텍스트가 있으면 먼저 확정 후 새로 연다

  let cssX = startX;
  let cssY = startY;

  const displayFontSize = Math.max(10, Math.round(currentFontSize * getDisplayScale()));

  const box = document.createElement('div');
  box.id = 'smartshot-text-box';
  box.style.position = 'absolute';
  box.style.left = cssX + 'px';
  box.style.top = cssY + 'px';
  box.style.zIndex = '5';

  const handle = document.createElement('div');
  handle.className = 'smartshot-text-handle';
  handle.textContent = '✥ 드래그해서 위치 이동';

  const input = document.createElement('textarea');
  input.rows = 1;
  input.value = initialText;
  input.style.display = 'block';
  input.style.color = currentTextColor;
  input.style.font = textFontString(displayFontSize, textBold);
  input.style.border = '1px dashed ' + currentTextColor;
  input.style.background = textBgTransparent ? 'transparent' : currentTextBgColor;
  input.style.padding = '2px 4px';
  input.style.resize = 'none';
  input.style.lineHeight = '1.3';
  // 줄바꿈(엔터)을 직접 입력하지 않는 한 줄을 바꾸지 않고, 문장이 길어지면 가로로
  // 늘어난다. 세로로는 실제 줄 수(엔터 입력)에 맞춰서만 늘어난다.
  input.style.whiteSpace = 'pre';
  input.style.overflow = 'hidden';

  box.appendChild(handle);
  box.appendChild(input);
  canvasWrap.appendChild(box);
  input.focus();

  function autoGrow() {
    measureCtx.font = textFontString(displayFontSize, textBold);
    const lines = input.value.split('\n');
    let maxWidth = 0;
    lines.forEach((line) => {
      const w = measureCtx.measureText(line || ' ').width;
      if (w > maxWidth) maxWidth = w;
    });
    const lineHeightPx = displayFontSize * 1.3;
    input.style.width = Math.max(60, Math.ceil(maxWidth) + 12) + 'px';
    input.style.height = Math.ceil(lines.length * lineHeightPx) + 8 + 'px';
  }
  input.addEventListener('input', autoGrow);
  autoGrow();
  if (initialText) {
    input.select();
  }

  // 핸들을 끌면 박스 위치를 옮긴다. mousedown에서 preventDefault로
  // 텍스트 입력창의 포커스가 풀리지 않게 한다 (포커스가 풀리면 바로 확정되어 버림).
  let dragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;

  function onDragMove(e) {
    if (!dragging) return;
    const rect = canvasWrap.getBoundingClientRect();
    cssX = e.clientX - rect.left - dragOffsetX;
    cssY = e.clientY - rect.top - dragOffsetY;
    box.style.left = cssX + 'px';
    box.style.top = cssY + 'px';
  }
  function onDragEnd() {
    dragging = false;
    document.removeEventListener('mousemove', onDragMove);
    document.removeEventListener('mouseup', onDragEnd);
  }
  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    dragging = true;
    const boxRect = box.getBoundingClientRect();
    dragOffsetX = e.clientX - boxRect.left;
    dragOffsetY = e.clientY - boxRect.top;
    document.addEventListener('mousemove', onDragMove);
    document.addEventListener('mouseup', onDragEnd);
  });

  function commit() {
    onDragEnd();
    const text = input.value.trim();
    if (!text) {
      box.remove();
      return;
    }

    // 글자가 실제로 보이던 textarea 안쪽(테두리/패딩 안쪽) 위치를 기준으로 그린다.
    // box.style.left/top(=cssX/cssY)은 ✥ 손잡이 기준점이라 그대로 쓰면 위치가 어긋난다.
    const inputRect = input.getBoundingClientRect();
    const wrapRect = canvasWrap.getBoundingClientRect();
    const computedInput = window.getComputedStyle(input);
    const textCssX = inputRect.left - wrapRect.left + (parseFloat(computedInput.borderLeftWidth) || 0) + (parseFloat(computedInput.paddingLeft) || 0);
    const textCssY = inputRect.top - wrapRect.top + (parseFloat(computedInput.borderTopWidth) || 0) + (parseFloat(computedInput.paddingTop) || 0);

    box.remove();
    const snapshot = pushUndoSnapshot();
    const rawPos = cssToCanvasPos(textCssX, textCssY);
    // 정수 좌표에 그려야 글자 가장자리가 들쭉날쭉하지 않고 또렷하게 나온다.
    const pos = { x: Math.round(rawPos.x), y: Math.round(rawPos.y) };
    const fontSize = currentFontSize;
    const lineHeight = Math.round(fontSize * 1.2);
    const lines = text.split('\n');

    ctx.save();
    ctx.font = textFontString(fontSize, textBold);
    ctx.textBaseline = 'top';

    if (!textBgTransparent) {
      let maxWidth = 0;
      lines.forEach((line) => {
        const w = ctx.measureText(line).width;
        if (w > maxWidth) maxWidth = w;
      });
      const padding = Math.round(fontSize * 0.15);
      ctx.fillStyle = currentTextBgColor;
      ctx.fillRect(
        pos.x - padding,
        pos.y - padding,
        Math.ceil(maxWidth) + padding * 2,
        lines.length * lineHeight + padding * 2
      );
    }

    ctx.fillStyle = currentTextColor;
    lines.forEach((line, i) => {
      ctx.fillText(line, pos.x, pos.y + i * lineHeight);
    });
    ctx.restore();

    lastAction = { type: 'text', snapshot, text, cssX, cssY };
    updateEditLastButton();
  }
  box._commit = commit;

  // Enter는 줄바꿈(기본 동작)으로 두고, Esc로 취소, 다른 곳을 클릭(blur)하면 확정한다.
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      onDragEnd();
      box.remove();
    }
  });
  input.addEventListener('blur', commit);
}

document.querySelectorAll('.annotate-tool').forEach((btn) => {
  btn.addEventListener('click', () => {
    const tool = btn.dataset.tool;
    document.querySelectorAll('.annotate-tool').forEach((b) => b.classList.remove('active'));
    canvasWrap.classList.remove('tool-box', 'tool-circle', 'tool-arrow', 'tool-line', 'tool-text', 'tool-mosaic');
    if (currentTool === tool) {
      currentTool = null;
    } else {
      currentTool = tool;
      btn.classList.add('active');
      canvasWrap.classList.add('tool-' + tool);
    }
  });
});

document.getElementById('annotate-shape-color').addEventListener('input', (e) => {
  currentShapeColor = e.target.value;
});

const thicknessInput = document.getElementById('annotate-thickness');
const thicknessValueEl = document.getElementById('annotate-thickness-value');
thicknessInput.addEventListener('input', (e) => {
  currentThickness = parseInt(e.target.value, 10);
  thicknessValueEl.textContent = String(currentThickness);
});

document.getElementById('annotate-text-color').addEventListener('input', (e) => {
  currentTextColor = e.target.value;
});

document.getElementById('annotate-text-bg-color').addEventListener('input', (e) => {
  currentTextBgColor = e.target.value;
});

document.getElementById('annotate-text-bg-transparent').addEventListener('change', (e) => {
  textBgTransparent = e.target.checked;
});

const boldToggleBtn = document.getElementById('annotate-bold-toggle');
boldToggleBtn.addEventListener('click', () => {
  textBold = !textBold;
  boldToggleBtn.classList.toggle('active', textBold);
});

const fontSizeInput = document.getElementById('annotate-fontsize');
const fontSizeValueEl = document.getElementById('annotate-fontsize-value');
fontSizeInput.addEventListener('input', (e) => {
  currentFontSize = parseInt(e.target.value, 10);
  fontSizeValueEl.textContent = String(currentFontSize);
});

document.getElementById('btn-undo').addEventListener('click', undoLast);

editLastBtn.addEventListener('click', () => {
  if (!lastAction) return;
  document.querySelectorAll('.annotate-tool').forEach((b) => b.classList.remove('active'));
  canvasWrap.classList.remove('tool-box', 'tool-circle', 'tool-arrow', 'tool-line', 'tool-text', 'tool-mosaic');
  currentTool = null;

  const { snapshot, text, cssX, cssY } = lastAction;
  lastAction = null;
  updateEditLastButton();
  const img = new Image();
  img.onload = () => {
    ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
    ctx.drawImage(img, 0, 0);
    openTextInput({ cssX, cssY, initialText: text });
  };
  img.src = snapshot;
});

canvasWrap.addEventListener('mousedown', (e) => {
  if (!currentTool || currentTool === 'text') return;
  dragStart = getCanvasPos(e);
});

// 텍스트 도구는 mousedown이 아닌 click(마우스를 뗀 뒤 확정되는 시점)에서 입력창을 연다.
// mousedown 시점에 입력창을 만들면 브라우저의 기본 포커스 처리와 경쟁하면서
// 입력창이 만들어진 직후 곧바로 blur되어 사라지는 문제가 있었다.
canvasWrap.addEventListener('click', (e) => {
  if (currentTool !== 'text') return;
  const wrapRect = canvasWrap.getBoundingClientRect();
  openTextInput({
    cssX: e.clientX - wrapRect.left,
    cssY: e.clientY - wrapRect.top
  });
});

canvasWrap.addEventListener('mousemove', (e) => {
  if (!currentTool || !dragStart || currentTool === 'text') return;
  drawPreview(currentTool, dragStart, getCanvasPos(e));
});

canvasWrap.addEventListener('mouseup', (e) => {
  if (!currentTool || !dragStart || currentTool === 'text') return;
  const pos = getCanvasPos(e);
  octx.clearRect(0, 0, overlayEl.width, overlayEl.height);
  const dx = pos.x - dragStart.x;
  const dy = pos.y - dragStart.y;
  if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
    pushUndoSnapshot();
    if (currentTool === 'box') drawBox(ctx, dragStart, pos, currentShapeColor);
    if (currentTool === 'circle') drawCircle(ctx, dragStart, pos, currentShapeColor);
    if (currentTool === 'arrow') drawArrow(ctx, dragStart, pos, currentShapeColor);
    if (currentTool === 'line') drawLine(ctx, dragStart, pos, currentShapeColor);
    if (currentTool === 'mosaic') applyMosaic(dragStart, pos);
  }
  dragStart = null;
});

// ---------- OCR / 복사 / 저장 ----------
const OCR_STATUS_LABELS = {
  'loading tesseract core': '엔진 불러오는 중',
  'initializing tesseract': '엔진 초기화 중',
  'loading language traineddata': '언어 데이터 다운로드 중 (처음 한 번만, 다소 걸려요)',
  'initializing api': '준비 중',
  'recognizing text': '텍스트 인식 중'
};

function ocrLogger(m) {
  if (!m || !m.status) return;
  const label = OCR_STATUS_LABELS[m.status] || m.status;
  const pct = typeof m.progress === 'number' ? ` ${Math.round(m.progress * 100)}%` : '';
  setStatus(`OCR - ${label}${pct}`);
}

async function getWorker() {
  if (worker) return worker;
  worker = await Tesseract.createWorker('kor+eng', 1, {
    workerPath: chrome.runtime.getURL('lib/worker.min.js'),
    corePath: chrome.runtime.getURL('lib/tesseract-core-simd-lstm.wasm.js'),
    workerBlobURL: false,
    cacheMethod: 'indexeddb',
    logger: ocrLogger
  });
  return worker;
}

function withTimeout(promise, ms, timeoutMessage) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(timeoutMessage)), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); }
    );
  });
}

async function runOcr() {
  ocrSection.style.display = 'flex';
  setStatus('OCR 준비 중...');
  textArea.value = '';
  try {
    const w = await getWorker();
    const { data } = await withTimeout(
      w.recognize(canvasEl),
      45000,
      '시간이 너무 오래 걸려요. 네트워크 상태를 확인하거나, 광고차단 확장이 언어 데이터 다운로드를 막고 있는지 확인해보세요.'
    );
    lastOcrText = (data.text || '').trim();
    textArea.value = lastOcrText;
    setStatus(`추출 완료 (${lastOcrText.length}자)`);
  } catch (err) {
    setStatus('OCR 실패: ' + err.message);
  }
}

document.getElementById('btn-ocr').addEventListener('click', runOcr);

document.getElementById('btn-copy-text').addEventListener('click', async () => {
  if (!textArea.value) return;
  await navigator.clipboard.writeText(textArea.value);
  flashStatus('텍스트가 클립보드에 복사되었습니다.');
});

document.getElementById('btn-copy-image').addEventListener('click', async () => {
  try {
    const blob = await new Promise((resolve) => canvasEl.toBlob(resolve, 'image/png'));
    await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
    flashStatus('이미지가 클립보드에 복사되었습니다.');
  } catch (err) {
    flashStatus('이미지 복사 실패: ' + err.message);
  }
});

saveBtn.addEventListener('click', async () => {
  const ts = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const ext = currentSettings.fileFormat === 'jpg' ? 'jpg' : 'png';
  const baseName = `SMARTSHOT_${ts.getFullYear()}${pad(ts.getMonth() + 1)}${pad(ts.getDate())}_${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}.${ext}`;

  try {
    const dataUrl = await toFormatDataUrl(canvasEl.toDataURL('image/png'), currentSettings.fileFormat);
    const folder = currentSettings.saveFolderMode === 'subfolder' && currentSettings.saveFolder
      ? currentSettings.saveFolder + '/'
      : '';
    const filename = folder + baseName;
    chrome.runtime.sendMessage({ type: 'SAVE_PNG', dataUrl, filename }, (res) => {
      if (res && res.fallback) {
        flashStatus(`${ext.toUpperCase()}로 저장되었습니다. (하위 폴더 생성이 막혀 있어 다운로드 폴더에 바로 저장됨)`);
      } else {
        flashStatus(`${ext.toUpperCase()}로 저장되었습니다.`);
      }
    });
  } catch (err) {
    flashStatus('저장 실패: ' + err.message);
  }
});

// ---------- 캡쳐 기록(히스토리) ----------
// 결과 창은 캡쳐할 때마다 새로 열리지 않고 재사용되므로, 지나간 캡쳐들을 모아두고
// 썸네일 목록에서 다시 불러와 재활용할 수 있게 한다.
let currentHistoryTs = null;
const historyStripEl = document.getElementById('history-strip');

async function getHistory() {
  const data = await chrome.storage.local.get(['smartshot_history']);
  return data.smartshot_history || [];
}

function renderHistoryStrip(history) {
  historyStripEl.innerHTML = '';
  history.forEach((item) => {
    const thumb = document.createElement('div');
    thumb.className = 'history-thumb' + (item.ts === currentHistoryTs ? ' active' : '');
    thumb.title = new Date(item.ts).toLocaleTimeString('ko-KR');
    const img = document.createElement('img');
    img.src = item.dataUrl;
    img.alt = '';
    thumb.appendChild(img);
    thumb.addEventListener('click', () => selectHistoryItem(item));
    historyStripEl.appendChild(thumb);
  });
  historyStripEl.scrollLeft = historyStripEl.scrollWidth;
}

// 주석/OCR 작업 상태를 비운다 (새 캡쳐를 불러오거나, 기록에서 다른 캡쳐를 고를 때 공통으로 쓴다).
function resetAnnotationState() {
  undoStack.length = 0;
  dragStart = null;
  currentTool = null;
  lastAction = null;
  updateEditLastButton();
  document.querySelectorAll('.annotate-tool').forEach((b) => b.classList.remove('active'));
  canvasWrap.classList.remove('tool-box', 'tool-circle', 'tool-arrow', 'tool-line', 'tool-text', 'tool-mosaic');
  const existingTextBox = document.getElementById('smartshot-text-box');
  if (existingTextBox) existingTextBox.remove();
  ocrSection.style.display = 'none';
  textArea.value = '';
  lastOcrText = '';
}

async function selectHistoryItem(item) {
  resetAnnotationState();
  currentHistoryTs = item.ts;
  await loadCapturedImage(item.dataUrl);
  setStatus('지난 캡쳐를 불러왔습니다. 필요하면 다시 편집하거나 저장할 수 있어요.');
  renderHistoryStrip(await getHistory());
}

// 결과 창은 캡쳐할 때마다 새로 열리지 않고 재사용된다. 그래서 새 캡쳐가 들어오면
// 기존 주석/OCR 상태를 초기화하고 새 이미지를 다시 불러와야 한다.
async function refreshFromStorage() {
  resetAnnotationState();

  const data = await chrome.storage.local.get(['smartshot_image', 'smartshot_autoOcr', 'smartshot_ts']);
  currentHistoryTs = data.smartshot_ts || null;

  if (!data.smartshot_image) {
    setStatus('표시할 캡쳐 이미지가 없습니다. 페이지의 SMARTSHOT 버튼으로 다시 캡쳐해 주세요.');
    renderHistoryStrip(await getHistory());
    return;
  }
  await loadCapturedImage(data.smartshot_image);
  setStatus('캡쳐 완료. 필요하면 OCR 텍스트 추출 또는 사각형/원형/화살표/선/텍스트/모자이크로 표시해보세요.');
  if (data.smartshot_autoOcr) runOcr();
  renderHistoryStrip(await getHistory());
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === 'NEW_CAPTURE') refreshFromStorage();
});

async function init() {
  await loadSettings();
  await refreshFromStorage();
}

init();
